/*
Student Name: Dibbyo Saha
Student ID: 501069290
 */
public class PassengerNotInManifestException extends Throwable {
    private PassengerNotInManifestException(){
        super("Not in Manifest");
    }
    PassengerNotInManifestException(String message){
        super(message);
    }
}
