/*
Student Name: Dibbyo Saha
Student ID: 501069290
 */

public class InvalidSeatTypeException extends Throwable {
    private InvalidSeatTypeException(){
        super("Seat type is not valid");
    }
    InvalidSeatTypeException(String message){
        super(message);
    }
}
