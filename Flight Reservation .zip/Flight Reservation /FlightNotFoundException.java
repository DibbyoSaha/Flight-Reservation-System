/*
Student Name: Dibbyo Saha
Student ID: 501069290
 */
public class FlightNotFoundException extends Throwable {
    public FlightNotFoundException(){
        super("Flight not found");
    }
    public FlightNotFoundException(String message){
        super(message);
    }
}
