/*
Student Name: Dibbyo Saha
Student ID: 501069290
 */
public class FlightIsFullException extends Exception{
    private FlightIsFullException(){
        super("Flight is full");
    }
    FlightIsFullException(String message){
        super(message);
    }
}
