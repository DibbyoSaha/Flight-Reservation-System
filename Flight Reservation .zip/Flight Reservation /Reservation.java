/*
Student Name: Dibbyo Saha
Student ID: 501069290
 */

public class Reservation {
    //Declaring variables
    String flightNum;
    String flightInfo;
    String name;
    String passport;
    String seat;
    String seatType;
    boolean firstClass;
    //Constructor to initialize the variables
    public Reservation(String flightNum, String info) {
        this.flightNum = flightNum;
        this.flightInfo = info;
    }
    //Constructor to initialize the variables
    public Reservation(String flightNum, String name, String passport) {
        this.flightNum = flightNum;
        this.name = name;
        this.passport = passport;
    }
    //Constructor to initialize the variables
    public Reservation(String flightNum, String info, String name, String passport, String seat, String seatType) {
        this.flightNum = flightNum;
        this.flightInfo = info;
        this.name = name;
        this.passport = passport;
        this.seat = seat;
        this.seatType = seatType;
    }
    //Getter method
    public String getFlightNum() {
        return flightNum;
    }
    //Getter method
    public String getFlightInfo() {
        return flightInfo;
    }
    //Setter method
    public void setFlightInfo(String flightInfo) {
        this.flightInfo = flightInfo;
    }
    //Compares and checks if the objects being compared are equal or not
    public boolean equals(Object other) {
        Reservation otherRes = (Reservation) other;
        return flightNum.equals(otherRes.flightNum) && name.equals(otherRes.name) && passport.equals(otherRes.passport);
    }
    //Method to print a statement
    public void print() {
        System.out.println(flightInfo + " " + name + " " + seat);
    }
}
