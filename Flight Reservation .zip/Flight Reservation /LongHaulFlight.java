/*
Student Name: Dibbyo Saha
Student ID: 501069290
 */

/*
 * A Long Haul Flight is a flight that travels a long distance and has two types of seats (First Class and Economy)
 */

public class LongHaulFlight extends Flight {
    //Declaring variables
    int firstClassPassengers;
    //Constructor to initialize variables
    public LongHaulFlight(String flightNum, String airline, String dest, String departure, int flightDuration, Aircraft aircraft) {
        super(flightNum, airline, dest, departure, flightDuration, aircraft);
        type = Flight.Type.LONGHAUL;
    }
    //Constructor to initialize variables
    public LongHaulFlight() {
        firstClassPassengers = 0;
        type = Flight.Type.LONGHAUL;
    }
    //Getter method
    public FlightType getFlightType() {
        type1 = Flight.FlightType.LONGHAUL;
        return type1;
    }
    //Method used to assign seats
    public void assignSeat(Passenger p) {
        int seat = random.nextInt(aircraft.getNumFirstClassSeats());
        p.setSeat("FCL" + seat);
    }
    //Method used to reserve flights for LongHaulFlight passengers
    public boolean reserveSeat(String name, String passport, String seatType, String seat) {
        if (seatType.equalsIgnoreCase("FCL")) {
            try {
                if (firstClassPassengers >= aircraft.getNumFirstClassSeats()) {
//                setErrorMessage("No First Class Seats Available");
//                return false;
                    throw new NoFCLAvailableException("No First Class Seats Available");
                }
            } catch (NoFCLAvailableException e) {
                System.out.println(e);
            }
            Passenger p = new Passenger(name, passport, "", seatType);
            try {
                if (manifest.indexOf(p) >= 0) {
//                setErrorMessage("Duplicate Passenger " + p.getName() + " " + p.getPassport());
//                return false;
                    throw new DuplicatePassengerException("Duplicate Passenger " + p.getName() + " " + p.getPassport());
                }
            } catch (DuplicatePassengerException e) {
                System.out.println(e);
            }
            assignSeat(p);
            manifest.add(p);
            firstClassPassengers++;
            return true;
        } else // economy passenger
            return super.reserveSeat(name, passport, seatType, seat);
    }
    //Method used to cancel flights for LongHaulFlight passengers
    public boolean cancelSeat(String name, String passport, String seatType) {
        if (seatType.equalsIgnoreCase("FCL")) {
            Passenger p = new Passenger(name, passport);
            try {
                if (manifest.indexOf(p) == -1) {
//                setErrorMessage("Passenger " + p.getName() + " " + p.getPassport() + " Not Found");
//                return false;
                    throw new PassengerNotFoundException("Passenger " + p.getName() + " " + p.getPassport() + " Not Found");
                }
            } catch (PassengerNotFoundException e) {
                System.out.println(e);
            }
            manifest.remove(p);
            if (firstClassPassengers > 0) firstClassPassengers--;
            return true;
        } else
            return super.cancelSeat(name, passport, seatType);
    }
    //Getter method
    public int getPassengerCount() {
        return getNumPassengers() + firstClassPassengers;
    }
    //seatsAvailable method to check if seats are available
    public boolean seatsAvailable(String seatType) {
        if (seatType.equals("FCL"))
            return firstClassPassengers < aircraft.getNumFirstClassSeats();
        else
            return super.seatsAvailable(seatType);
    }
    //Method that prints out a statement making everything in string
    public String toString() {
        return super.toString() + "\t LongHaul";
    }
}
