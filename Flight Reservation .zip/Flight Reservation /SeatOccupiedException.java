/*
Student Name: Dibbyo Saha
Student ID: 501069290
 */
public class SeatOccupiedException extends Exception {
    private SeatOccupiedException(){
        super("This seat is currently occupied");
    }
    private SeatOccupiedException(String message){
        super(message);
    }
}