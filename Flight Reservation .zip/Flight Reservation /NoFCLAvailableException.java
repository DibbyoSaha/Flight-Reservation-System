/*
Student Name: Dibbyo Saha
Student ID: 501069290
 */

public class NoFCLAvailableException extends Throwable {
    public NoFCLAvailableException(){
        super("No FCL Available");
    }
    public NoFCLAvailableException(String message){
        super(message);
    }
}
