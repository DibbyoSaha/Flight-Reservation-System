/*
Student Name: Dibbyo Saha
Student ID: 501069290
 */
public class DuplicatePassengerException extends Exception {
    public DuplicatePassengerException(){
        super("Dublicate passenger error");
    }
    public DuplicatePassengerException(String message){
        super(message);
    }
}