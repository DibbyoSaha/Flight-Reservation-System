/*
Student Name: Dibbyo Saha
Student ID: 501069290
 */

public class PassengerNotFoundException extends Throwable {
    public PassengerNotFoundException() {
        super("Passenger not found");
    }

    public PassengerNotFoundException(String message) {
        super(message);
    }
}
